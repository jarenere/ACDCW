#ifndef CONFIG_H
#define CONFIG_H

@TOP@

/* Base IO address for parallel port */
#undef IOPORT

@BOTTOM@

#endif
