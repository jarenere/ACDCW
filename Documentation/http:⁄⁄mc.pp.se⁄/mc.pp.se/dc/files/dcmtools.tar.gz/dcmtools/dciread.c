#include "config.h"
#include "nexusio.h"
#include "filesys.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>


#define SECTOR_SIZE 512

extern int optind;
extern char *optarg;

int main(int argc, char *argv[])
{
  int c, sec;
  FILE *f = stdout;
  unsigned char buf[SECTOR_SIZE];
  struct superblock super;
  struct dir_iterator iter;
  struct dir_entry ent;
  nio_setup();
#ifdef HAVE_SETUID
  setuid(getuid());
#endif
  while((c=getopt(argc, argv, "hb:"))!=EOF)
    switch(c) {
     case 'h':
       fprintf(stderr, "Usage: %s [-h] [-b bank] filename [dcifile]\n", argv[0]);
       return 0;
     case 'b':
       if(!nio_set_bank(atoi(optarg)))
	 return 1;
       break;
    }
  if(optind>=argc) {
    fprintf(stderr, "%s: Too few arguments.\n", argv[0]);
    return 1;
  }
  if(!fs_get_superblock(&super))
    return 1;
  fs_open_dir(&super, &iter);
  if(!fs_next_named_dir_entry(&iter, &ent, argv[optind++])) {
    fprintf(stderr, "%s: No such file\n", argv[optind-1]);
    return 1;
  }
  if(optind<argc)
    if((f=fopen(argv[optind], "wb"))==NULL) {
      fprintf(stderr, "Failed to open \"%s\" for output.\n", argv[optind]);
      return 1;
    }
  if(fwrite(ent.entry, sizeof(ent.entry), 1, f) != 1) {
    fprintf(stderr, "Failed to write DCI header.\n");
    return 1;
  }
  sec = ent.entry[2]|(ent.entry[3]<<8);
  while(sec != 0xfffa) {
    if(!(nio_read(sec*SECTOR_SIZE, SECTOR_SIZE, buf, 0)))
      return 1;
    if(fwrite(buf, SECTOR_SIZE, 1, f) != 1) {
      fprintf(stderr, "Failed to write sector to DCI file.\n");
      return 1;
    }
    sec = fs_get_fat(&super, sec);
  }
  if(f != stdout)
    fclose(f);
  return 0;
}
