#include "config.h"
#include "nexusio.h"
#include "filesys.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>


#define SECTOR_SIZE 512

extern int optind;
extern char *optarg;

int main(int argc, char *argv[])
{
  int c, ns, old=0, os=0, force=0, sec, lsec, sec0=0;
  FILE *f = stdin;
  unsigned char hdr[0x20], *data;
  struct superblock super;
  struct dir_iterator iter;
  struct dir_entry ent;
  nio_setup();
#ifdef HAVE_SETUID
  setuid(getuid());
#endif
  while((c=getopt(argc, argv, "hb:f"))!=EOF)
    switch(c) {
     case 'h':
       fprintf(stderr, "Usage: %s [-h] [-b bank] [-f] [dcifile]\n", argv[0]);
       return 0;
     case 'f':
       force=1;
       break;
     case 'b':
       if(!nio_set_bank(atoi(optarg)))
	 return 1;
       break;
    }
  if(optind<argc)
    if((f=fopen(argv[optind], "rb"))==NULL) {
      fprintf(stderr, "Failed to open \"%s\" for input.\n", argv[optind]);
      return 1;
    }
  if(fread(hdr, sizeof(hdr), 1, f) != 1) {
    fprintf(stderr, "Failed to read DCI header.\n");
    return 1;
  }
  if(!fs_get_superblock(&super))
    return 1;
  fs_open_dir(&super, &iter);
  if(fs_next_named_dir_entry(&iter, &ent, (char *)(hdr+4)))
    if(force) {
      old = 1;
      os = ent.entry[0x18]|(ent.entry[0x19]<<8);
    } else {
      fprintf(stderr, "%.12s: file already exits.\n", (char *)(hdr+4));
      return 1;
    }
  ns = hdr[0x18]|(hdr[0x19]<<8);
  if(ns > os && ns-os > fs_count_free(&super)) {
    fprintf(stderr, "Bank is full.  Need %d blocks, have %d.\n", ns,
	    fs_count_free(&super)+os);
    return 1;    
  }
  if(hdr[0] == 0xcc) {
    if(old && ent.entry[0] == 0xcc)
      sec = os;
    else
      sec = 0;
    for(; sec<ns; sec++)
      if(fs_get_fat(&super, sec)!=0xfffc) {
	fprintf(stderr, "Not enough room for GAME.  Need %d, have %d.\n",
		ns, sec);
	return 1;
      }
  }
  if((data = malloc(ns * SECTOR_SIZE))==NULL) {
    fprintf(stderr, "Out of memory!\n");
    return 1;
  }
  if(fread(data, SECTOR_SIZE, ns, f) != ns) {
    fprintf(stderr, "Failed to read %d sectors from DCI file.\n", ns);
    free(data);
    return 1;
  }
  if(f != stdin)
    fclose(f);
  if(old) {
    ent.entry[0] = 0;
    if(!fs_write_dir_entry(&ent)) {
      free(data);
      return 1;
    } else {
      unsigned int b;
      for(b=ent.entry[2]|(ent.entry[3]<<8); b!=0xfffa && b!=0xfffc; ) {
	unsigned int n = fs_get_fat(&super, b);
	fs_set_fat(&super, b, 0xfffc);
	b = n;
      }
      if(!fs_sync_superblock(&super)) {
	free(data);
	return 1;
      }
    }
  } else {
    fs_open_dir(&super, &iter);
    if(!fs_next_empty_dir_entry(&iter, &ent)) {
      fprintf(stderr, "No empty directory entries!\n");
      free(data);
      return 1;
    }
  }
  for(sec=0; sec<ns; sec++) {
    int s;
    if(hdr[0] == 0xcc)
      s = sec;
    else
      s = fs_find_free_block(&super);
    if(s == 0xfffa || s == 0xfffc || fs_get_fat(&super, s) != 0xfffc) {
      fprintf(stderr, "Block allocation failure!\n");
      free(data);
      return 1;
    }
    if(sec)
      fs_set_fat(&super, lsec, s);
    else
      sec0 = s;
    lsec = s;
    fs_set_fat(&super, s, 0xfffa);
    if(!nio_write(s*SECTOR_SIZE, SECTOR_SIZE, data+sec*SECTOR_SIZE, 0)) {
      free(data);
      return 1;
    }
  }
  free(data);
  memcpy(ent.entry, hdr, 0x20);
  ent.entry[2] = sec0 & 0xff;
  ent.entry[3] = (sec0 >> 8) & 0xff;
  if(!fs_write_dir_entry(&ent) || !fs_sync_superblock(&super))
    return 1;
  return 0;
}
