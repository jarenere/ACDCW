#include "config.h"
#include "nexusio.h"

#include <stdio.h>
#include <unistd.h>


#define NUM_SECTORS 256
#define SECTOR_SIZE 512

static unsigned char dcm[(NUM_SECTORS+1)*SECTOR_SIZE];

extern int optind;
extern char *optarg;

int main(int argc, char *argv[])
{
  int c;
  FILE *f = stdin;
  nio_setup();
#ifdef HAVE_SETUID
  setuid(getuid());
#endif
  while((c=getopt(argc, argv, "hb:"))!=EOF)
    switch(c) {
     case 'h':
       fprintf(stderr, "Usage: %s [-h] [-b bank] [dcmfile]\n", argv[0]);
       return 0;
     case 'b':
       if(!nio_set_bank(atoi(optarg)))
	 return 1;
       break;
    }
  if(optind<argc)
    if((f=fopen(argv[optind], "rb"))==NULL) {
      fprintf(stderr, "Failed to open \"%s\" for input.\n", argv[optind]);
      return 1;
    }
  if(fread(dcm, SECTOR_SIZE, NUM_SECTORS+1, f) != NUM_SECTORS) {
    fprintf(stderr, "Illegal input size, must be 128K\n");
    return 1;
  }
  if(f != stdin)
    fclose(f);
  if(!nio_write(0, NUM_SECTORS*SECTOR_SIZE, dcm, 0))
    return 1;
  return 0;
}
