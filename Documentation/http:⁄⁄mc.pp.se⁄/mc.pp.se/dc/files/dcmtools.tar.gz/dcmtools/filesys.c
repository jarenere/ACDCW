#include "config.h"
#include "nexusio.h"
#include "filesys.h"

#include <stdio.h>
#include <string.h>


int fs_get_superblock(struct superblock *s)
{
  int i;
  if(!nio_read(0xff*0x200, 0x200, s->root, 1))
    return 0;
  for(i=0; i<16; i++)
    if(s->root[i] != 0x55) {
      fprintf(stderr, "Bank not formatted\n");
      return 0;
    }
  if(!nio_read((s->root[0x46]+(s->root[0x47]<<8))*0x200, 0x200, s->fat, 1))
    return 0;
  s->root_modified=0;
  s->fat_modified=0;
  return 1;
}

int fs_sync_superblock(struct superblock *s)
{
  if(s->fat_modified &&
     !nio_write((s->root[0x46]+(s->root[0x47]<<8))*0x200, 0x200, s->fat, 1))
    return 0;
  s->fat_modified = 0;
  if(s->root_modified &&
     !nio_write(0xff*0x200, 0x200, s->root, 1))
    return 0;
  s->root_modified = 0;
  return 1;
}

unsigned int fs_get_fat(struct superblock *s, unsigned int n)
{
  if(n>255) return 0xfffc;
  n<<=1;
  return s->fat[n]|(s->fat[n+1]<<8);
}

void fs_set_fat(struct superblock *s, unsigned int n, unsigned int l)
{
  if(n>255) return;
  n<<=1;
  s->fat[n]=l&0xff;
  s->fat[n+1]=(l>>8)&0xff;
  s->fat_modified = 1;
}

int fs_count_free(struct superblock *s)
{
  int i, n = 0;
  for(i=0; i<200; i++)
    if(fs_get_fat(s, i)==0xfffc)
      n++;
  return n;
}

int fs_find_free_block(struct superblock *s)
{
  int i;
  for(i=199; i>=0; --i)
    if(fs_get_fat(s, i)==0xfffc)
      return i;
  return 0xfffc;
}

void fs_open_dir(struct superblock *s, struct dir_iterator *i)
{
  memset(i, 0, sizeof(struct dir_iterator));
  i->next_blk = s->root[0x4a]|(s->root[0x4b]<<8);
  i->dcnt = 999;
  i->super = s;
}

int fs_next_dir_entry(struct dir_iterator *i, struct dir_entry *d)
{
  d->dir = i;
  if(i->dcnt >= 15) {
    i->this_blk = i->next_blk;
    if(i->this_blk == 0xfffa || i->this_blk == 0xfffc)
      return 0;
    if(!nio_read(i->this_blk*0x200, 0x200, i->blk, 1))
      return 0;
    i->next_blk = fs_get_fat(i->super, i->this_blk);
    i->dcnt = -1;
  }
  memcpy(d->entry, &i->blk[++i->dcnt*0x20], 0x20);
  d->addr = i->this_blk*0x200+i->dcnt*0x20;
  return 1;
}

int fs_next_named_dir_entry(struct dir_iterator *i, struct dir_entry *d, char *name)
{
  while(fs_next_dir_entry(i, d))
    if(d->entry[0] && !strncmp(d->entry+4, name, 12))
      return 1;
  return 0;
}

int fs_next_empty_dir_entry(struct dir_iterator *i, struct dir_entry *d)
{
  while(fs_next_dir_entry(i, d))
    if(!d->entry[0])
      return 1;
  return 0;
}

int fs_write_dir_entry(struct dir_entry *d)
{
  return nio_write(d->addr, 0x20, d->entry, 1);
}
