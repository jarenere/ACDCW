struct superblock {
  unsigned char root[512];
  unsigned char fat[512];
  int root_modified;
  int fat_modified;
};

struct dir_iterator {
  unsigned char blk[512];
  unsigned int this_blk, next_blk;
  int dcnt;
  struct superblock *super;
};

struct dir_entry {
  unsigned char entry[0x20];
  long addr;
  struct dir_iterator *dir;
};

extern int fs_get_superblock(struct superblock *s);
extern int fs_sync_superblock(struct superblock *s);
extern unsigned int fs_get_fat(struct superblock *s, unsigned int n);
extern void fs_set_fat(struct superblock *s, unsigned int n, unsigned int l);
int fs_count_free(struct superblock *s);
extern int fs_find_free_block(struct superblock *s);
extern void fs_open_dir(struct superblock *s, struct dir_iterator *i);
extern int fs_next_dir_entry(struct dir_iterator *i, struct dir_entry *d);
extern int fs_next_named_dir_entry(struct dir_iterator *i, struct dir_entry *d, char *name);
extern int fs_next_empty_dir_entry(struct dir_iterator *i, struct dir_entry *d);
extern int fs_write_dir_entry(struct dir_entry *d);
