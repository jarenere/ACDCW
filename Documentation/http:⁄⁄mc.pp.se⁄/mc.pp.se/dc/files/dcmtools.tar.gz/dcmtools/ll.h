extern void w_lpdata(unsigned char n);
extern void w_lpcontrol(unsigned char n);
extern unsigned char r_lpstatus();
extern void ll_usleep(int n);
extern void ll_setup();
