#include "config.h"
#include "ll.h"

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

#include <exec/types.h>
#include <exec/io.h>
#include <resources/misc.h>
#include <resources/cia.h>
#include <devices/timer.h>
#include <hardware/cia.h>
#include <proto/exec.h>
#include <proto/misc.h>
#include <proto/cia.h>
#include <proto/timer.h>


struct Library *MiscBase = NULL;
struct Library *CIAAResource = NULL;
struct Device *TimerBase = NULL;

static BOOL alloc_pbits = FALSE, alloc_pport = FALSE;

static struct MsgPort *timer_port = NULL;
static struct timerequest *timer_req = NULL;

extern volatile struct CIA ciaa, ciab;


#ifdef __SASC
void __regargs _CXBRK(int sig)
{
  __sigfunc[SIGINT] = SIG_IGN;
  fprintf(stderr, "*** Break\n");
  exit(20);
}
#endif


void w_lpdata(unsigned char n)
{
  /* Write D0-D7 */
  ciaa.ciaprb = n;
}

void w_lpcontrol(unsigned char n)
{
  /* Can't write /STROBE manually on Amiga. */
  /* See README about how to resolder cable. */
}

unsigned char r_lpstatus()
{
  /* Can't read /ACK manually on Amiga.      */
  /* See README about how to resolder cable. */

  /* Read SEL */
  return (unsigned char)((ciab.ciapra>>CIAB_PRTRSEL)&1);
}

void ll_usleep(int n)
{
  struct timeval now, target;
  if(n<1)
    return;
#if 0
  timer_req->tr_node.io_Command = TR_ADDREQUEST;
  timer_req->tr_time.tv_secs = 0;
  timer_req->tr_time.tv_micro = n;
  DoIO((struct IORequest *)timer_req);
#else
  target.tv_secs = 0;
  target.tv_micro = n;
  GetSysTime(&now);
  AddTime(&target, &now);
  do GetSysTime(&now); while(CmpTime(&target, &now)<0);
#endif
}

static void ll_shutdown()
{
  if(alloc_pbits)
    FreeMiscResource(MR_PARALLELBITS);
  if(alloc_pport)
    FreeMiscResource(MR_PARALLELPORT);
  if(TimerBase != NULL)
    CloseDevice((struct IORequest *)timer_req);
  if(timer_req != NULL)
    DeleteIORequest((struct IORequest *)timer_req);
  if(timer_port != NULL)
    DeleteMsgPort(timer_port);
}

void ll_setup()
{
  char *curruser;
  atexit(ll_shutdown);
  if(SysBase->LibNode.lib_Version < 36) {
    fprintf(stderr, "KS 2.0+ required\n");
    exit(1);
  }
  if((timer_port = CreateMsgPort()) == NULL) {
    fprintf(stderr, "Failed to allocate timer request\n");
    exit(1);
  }
  if((timer_req = (struct timerequest *)
	CreateIORequest(timer_port, sizeof(struct timerequest))) == NULL) {
    fprintf(stderr, "Failed to allocate timer request\n");
    exit(1);
  }
  if(OpenDevice(TIMERNAME, UNIT_MICROHZ, (struct IORequest *)timer_req, 0)) {
    fprintf(stderr, "Failed to open %s\n", TIMERNAME);
    exit(1);
  }
  TimerBase = timer_req->tr_node.io_Device;
  if(TimerBase->dd_Library.lib_Version < 36) {
    fprintf(stderr, "KS 2.0+ required\n");
    exit(1);
  }
  if((MiscBase = OpenResource(MISCNAME))==NULL) {
    fprintf(stderr, "Failed to open %s\n", MISCNAME);
    exit(1);
  }
  if((CIAAResource = OpenResource(CIAANAME))==NULL) {
    fprintf(stderr, "Failed to open %s\n", CIAANAME);
    exit(1);
  }
  if((curruser = AllocMiscResource(MR_PARALLELPORT, "dcmtools")) != NULL) {
    fprintf(stderr, "Parallel port already allocated by %s\n", curruser);
    exit(1);
  }
  alloc_pport = TRUE;
  if((curruser = AllocMiscResource(MR_PARALLELBITS, "dcmtools")) != NULL) {
    fprintf(stderr, "Parallel bits already allocated by %s\n", curruser);
    exit(1);
  }
  alloc_pbits = TRUE;

  AbleICR(CIAAResource, CIAICRF_FLG);
  SetICR(CIAAResource, CIAICRF_FLG);

  Disable();
  ciab.ciaddra &= ~CIAF_PRTRSEL;
  ciaa.ciaddrb = 0xff;
  ciaa.ciaprb = 0;
  Enable();

}
