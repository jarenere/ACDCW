#include "config.h"
#include "ll.h"

#include <stdio.h>
#include <sys/types.h>
#include <asm/io.h>
#include <unistd.h>

#define LPDATA (IOPORT)
#define LPSTATUS (IOPORT+1)
#define LPCONTROL (IOPORT+2)

void w_lpdata(unsigned char n)
{
  /* Write D0-D7 */
  asm("outb (%%dx)" : : "a" (n), "d" (LPDATA));
}

void w_lpcontrol(unsigned char n)
{
  /* Write /STROBE */
  asm("outb (%%dx)" : : "a" (n), "d" (LPCONTROL));
}

unsigned char r_lpstatus()
{
  /* Read /ACK */
  unsigned char r;
  asm("inb (%%dx)" : "=a" (r) : "d" (LPSTATUS));
  /* Also check SEL, in order to be compatible
     with modified cable */
  return (r>>6)&(r>>4)&1;
}

void ll_usleep(int n)
{
  for(n; n > 0; n--)
    inb(80);
}

void ll_setup()
{
  if (ioperm((IOPORT), 3, 1) || ioperm(80, 1, 1)) {
    fprintf(stderr, "Failed to set IOPL for I/O, make sure program is setuid root.\n");
    exit(1);
  }
}
