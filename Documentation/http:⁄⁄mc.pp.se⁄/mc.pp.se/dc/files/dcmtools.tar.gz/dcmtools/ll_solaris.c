#include "config.h"
#include "ll.h"

#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/sysi86.h>
#include <sys/psw.h>

#define LPDATA (IOPORT)
#define LPSTATUS (IOPORT+1)
#define LPCONTROL (IOPORT+2)

void w_lpdata(unsigned char n)
{
  /* Write D0-D7 */
  asm("outb (%%dx)" : : "a" (n), "d" (LPDATA));
}

void w_lpcontrol(unsigned char n)
{
  /* Write /STROBE */
  asm("outb (%%dx)" : : "a" (n), "d" (LPCONTROL));
}

unsigned char r_lpstatus()
{
  /* Read /ACK */
  unsigned char r;
  asm("inb (%%dx)" : "=a" (r) : "d" (LPSTATUS));
  /* Also check SEL, in order to be compatible
     with modified cable */
  return (r>>6)&(r>>4)&1;
}

void ll_usleep(int n)
{
  hrtime_t end = gethrtime()+n*1000;
  while(gethrtime()<end);
}

void ll_setup()
{
  if (sysi86(SI86V86, V86SC_IOPL, PS_IOPL) < 0) {
    fprintf(stderr, "Failed to set IOPL for I/O, make sure program is setuid root.\n");
    exit(1);
  }
}
