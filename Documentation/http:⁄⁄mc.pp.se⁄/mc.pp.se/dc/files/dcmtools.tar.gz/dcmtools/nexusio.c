#include "config.h"
#include "ll.h"
#include "nexusio.h"

#include <stdio.h>
#include <string.h>


#define DELAY1 2
#define DELAY2 30

#define MAXCHUNK 0x4000


static void nio_enter()
{
  int n=0;
  w_lpcontrol(0); /* release STROBE */
  w_lpdata(0x81);
  do ll_usleep(DELAY2); while(!r_lpstatus() && ++n<1000);
  n=0;
  w_lpcontrol(1); /* assert STROBE */
  w_lpdata(1);
  do ll_usleep(DELAY2); while(r_lpstatus() && ++n<1000);
  ll_usleep(DELAY2);
}

static void nio_leave()
{
  w_lpcontrol(0); /* release STROBE */
  w_lpdata(0x81);
}

static int nio_exchange(int n)
{
  int i, r=0;
  for(i=0; i<8; i++) {
    int z = ((n&0x80)? 3:1);
    w_lpdata(z);
    w_lpdata(z&2);
    ll_usleep(DELAY1);
    w_lpdata(z);
    r<<=1;
    r |= r_lpstatus();
    ll_usleep(DELAY1);
    n = (n&0x7fff)<<1;
  }
  ll_usleep(DELAY2);
  return r;
}

static int nio_exchange_cs(int n, int *cs)
{
  *cs ^= n;
  return nio_exchange(n);
}

static int nio_low_read(long addr, int nbyt, unsigned char *dst, int bswap)
{
  int i, tmp, cs = 0;

  bswap = (bswap? 3:0);

  nio_enter();

  if(nio_exchange_cs(0x02, &cs) != 0xa9 ||
     nio_exchange_cs(0xa9, &cs) != 0x55) {
    nio_leave();
    fprintf(stderr, "READ PHASE ERROR addr = %05lx\n", addr);
    return 0;
  }

  nio_exchange_cs((addr)&0xff, &cs);
  nio_exchange_cs((addr>>8)&0xff, &cs);
  nio_exchange_cs((addr>>16)&0xff, &cs);
  nio_exchange_cs((addr>>24)&0xff, &cs);

  nio_exchange_cs((nbyt)&0xff, &cs);
  tmp = nio_exchange_cs((nbyt>>8)&0xff, &cs);

  for(i=0; i<nbyt; i++)
    dst[i^bswap] = tmp = nio_exchange_cs(tmp, &cs);

  if(nio_exchange(cs) != cs) {
    nio_leave();
    fprintf(stderr, "READ ERROR addr = %05lx\n", addr);
    return 0;
  }

  nio_leave();
  return 1;
}

static int nio_low_write(long addr, unsigned char *src, int bswap)
{
  int i, cs = 0;

  bswap = (bswap? 3:0);

  nio_enter();

  if(nio_exchange_cs(0x02, &cs) != 0xa9 ||
     nio_exchange_cs(0x55, &cs) != 0x55) {
    nio_leave();
    fprintf(stderr, "WRITE PHASE ERROR addr = %05lx\n", addr);
    return 0;
  }

  nio_exchange_cs((addr)&0xff, &cs);
  nio_exchange_cs((addr>>8)&0xff, &cs);
  nio_exchange_cs((addr>>16)&0xff, &cs);
  nio_exchange_cs((addr>>24)&0xff, &cs);

  for(i=0; i<0x80; i++)
    nio_exchange_cs(src[i^bswap], &cs);

  if(nio_exchange(cs) != cs) {
    nio_leave();
    fprintf(stderr, "WRITE ERROR addr = %05lx\n", addr);
    return 0;
  }

  nio_leave();
  return 1;
}

static int nio_low_get_bank()
{
  int bl, bh, cs = 0;

  nio_enter();

  if(nio_exchange_cs(0x40, &cs) != 0xa9 ||
     nio_exchange_cs(0x7e, &cs) != 0x55) {
    nio_leave();
    fprintf(stderr, "GET_BANK PHASE ERROR\n");
    return -1;
  }

  bl = nio_exchange_cs(0x55, &cs);
  bh = nio_exchange_cs(bl, &cs);

  if(nio_exchange(cs) != cs) {
    nio_leave();
    fprintf(stderr, "GET_BANK ERROR");
    return -1;
  }

  nio_leave();
  return (bh<<8)|bl;
}

static int nio_low_set_bank(int b)
{
  int cs = 0;

  nio_enter();

  if(nio_exchange_cs(0x40, &cs) != 0xa9 ||
     nio_exchange_cs(0x6a, &cs) != 0x55) {
    nio_leave();
    fprintf(stderr, "SET_BANK PHASE ERROR\n");
    return 0;
  }

  nio_exchange_cs(b&0xff, &cs);
  nio_exchange_cs((b>>8)&0xff, &cs);

  if(nio_exchange(cs) != cs) {
    nio_leave();
    fprintf(stderr, "SET_BANK ERROR");
    return 0;
  }

  nio_leave();
  return 1;
}

int nio_read(long addr, int nbyt, unsigned char *dst, int bswap)
{
  int n;

  if(nbyt<=0)
    return 1;

  while(nbyt>MAXCHUNK) {
    if(!nio_read(addr, MAXCHUNK, dst, bswap))
      return 0;
    addr += MAXCHUNK;
    nbyt -= MAXCHUNK;
    dst += MAXCHUNK;
  }

  if((nbyt&3) && nbyt>4) {
    if(!nio_read(addr, nbyt&~3, dst, bswap))
      return 0;
    addr += nbyt&~3;
    dst += nbyt&~3;
    nbyt &= 3;
  }

  if(nbyt&3) {
    unsigned char tmp[4];
    if(!nio_read(addr, 4, tmp, bswap))
      return 0;
    memcpy(dst, tmp, nbyt);
    return 1;
  }

  for(n=0; n<5; n++)
    if(nio_low_read(addr, nbyt, dst, bswap))
      return 1;
  fprintf(stderr, "READ ABORTED AFTER 5 TRIES\n");
  return 0;
}

int nio_write(long addr, int nbyt, unsigned char *src, int bswap)
{
  int n;
  unsigned char tmp[0x80];

  if(nbyt<=0)
    return 1;

  if(addr&0x7f)
    if((addr&0x7f)+nbyt > 0x80) {
      if(!nio_write(addr, 0x80-(addr&0x7f), src, bswap))
	return 0;
      src += 0x80-(addr&0x7f);
      nbyt -= 0x80-(addr&0x7f);
      addr += 0x80-(addr&0x7f);
    } else {
      if(!nio_read(addr&~0x7f, 0x80, tmp, bswap))
	return 0;
      memcpy(tmp+(addr&0x7f), src, nbyt);
      addr &= ~0x7f;
      nbyt = 0x80;
      src = tmp;
    }

  while(nbyt>0x80) {
    if(!nio_write(addr, 0x80, src, bswap))
      return 0;
    addr += 0x80;
    nbyt -= 0x80;
    src += 0x80;
  }

  if(nbyt<0x80) {
    if(!nio_read(addr, 0x80, tmp, bswap))
      return 0;
    memcpy(tmp, src, nbyt);
    src = tmp;
    nbyt = 0x80;
  }

  for(n=0; n<5; n++)
    if(nio_low_write(addr, src, bswap))
      return 1;
  fprintf(stderr, "WRITE ABORTED AFTER 5 TRIES\n");
  return 0;
}

int nio_get_bank()
{
  int n, b;
  for(n=0; n<5; n++)
    if((b=nio_low_get_bank())>=0)
      return b;
  fprintf(stderr, "GET_BANK ABORTED AFTER 5 TRIES\n");
  return -1;
}

int nio_set_bank(int b)
{
  int n;
  for(n=0; n<5; n++)
    if(nio_low_set_bank(b))
      return 1;
  fprintf(stderr, "SET_BANK ABORTED AFTER 5 TRIES\n");
  return 0;
}

void nio_setup()
{
  ll_setup();
  atexit(nio_leave);
}
