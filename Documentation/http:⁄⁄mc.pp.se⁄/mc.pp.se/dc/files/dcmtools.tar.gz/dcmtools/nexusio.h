extern void nio_setup();
extern int nio_read(long addr, int nbyt, unsigned char *dst, int bswap);
extern int nio_write(long addr, int nbyt, unsigned char *src, int bswap);
extern int nio_get_bank();
extern int nio_set_bank(int b);

