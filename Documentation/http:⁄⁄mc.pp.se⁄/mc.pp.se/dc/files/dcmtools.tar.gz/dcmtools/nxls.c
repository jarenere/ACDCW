#include "config.h"
#include "filesys.h"

#include <stdio.h>
#include <unistd.h>


extern int optind;
extern char *optarg;

static void list(struct dir_entry *d, int l)
{
  static char *wday[] = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };
  if(l) {
    printf("%c %s %3d ", (d->entry[1]? '-':'c'),
	   (d->entry[0]==0x33? "DATA":(d->entry[0]==0xcc? "GAME":"????")),
	   d->entry[0x18]|(d->entry[0x19]<<8));
    printf("%s %2x%02x/%02x/%02x %02x:%02x:%02x ", wday[d->entry[0x17]],
	   d->entry[0x10], d->entry[0x11], d->entry[0x12], d->entry[0x13],
	   d->entry[0x14], d->entry[0x15], d->entry[0x16]);
  }
  printf("%.12s\n", d->entry+4);
}

int main(int argc, char *argv[])
{
  int c, l=0, rc=0;
  struct superblock super;
  struct dir_iterator iter;
  struct dir_entry ent;
  nio_setup();
#ifdef HAVE_SETUID
  setuid(getuid());
#endif
  while((c=getopt(argc, argv, "hb:l"))!=EOF)
    switch(c) {
     case 'h':
       fprintf(stderr, "Usage: %s [-h] [-b bank] [-l] [filename...]\n", argv[0]);
       return 0;
     case 'b':
       if(!nio_set_bank(atoi(optarg)))
	 return 1;
       break;
     case 'l':
       l=1;
       break;
    }
  if(!fs_get_superblock(&super))
    return 1;
  if(optind<argc)
    while(optind<argc) {
      fs_open_dir(&super, &iter);
      if(fs_next_named_dir_entry(&iter, &ent, argv[optind++]))
	list(&ent, l);
      else {
	fprintf(stderr, "%s: No such file\n", argv[optind-1]);
	rc = 1;
      }
    }
  else {
    fs_open_dir(&super, &iter);
    while(fs_next_dir_entry(&iter, &ent))
      if(ent.entry[0])
	list(&ent, l);
    if(l)
      printf("%3d free blocks\n", fs_count_free(&super));
  }
  return rc;
}
