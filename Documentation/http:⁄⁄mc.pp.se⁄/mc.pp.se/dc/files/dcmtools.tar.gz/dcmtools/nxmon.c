#include "config.h"
#include "nexusio.h"

#include <stdio.h>
#include <unistd.h>


extern int optind;
extern char *optarg;

void memdump(int addr)
{
  char buf[16];
  int i, j;
  for(i=0; i<16; i++)
    if(nio_read(addr+i*16, 16, buf, 1)) {
      printf("%05x:", addr+i*16);
      for(j=0; j<16; j++)
	printf(" %02x", buf[j]&0xff);
      printf(" : ");
      for(j=0; j<16; j++)
	printf("%c", ((buf[j]&0x60)? buf[j]:'.'));
      printf("\n");
    }
}

void do_mon()
{
  char cmd[128];
  fprintf(stderr, "NXMON\n");
  for(;;) {
    fprintf(stderr, "> ");
    if(fgets(cmd, sizeof(cmd), stdin)==NULL ||
       cmd[0]=='x')
      return;
    switch(cmd[0]) {
     case '\0': break;
     case 'm':
       memdump(strtol(cmd+1, NULL, 16));
       break;
     case 'e':
       {
	 char *p, *op;
	 int addr = strtol(cmd+1, &p, 16);
	 unsigned char val;
	 if(!p || p==cmd+1) break;
	 while((val = strtol(op=p, &p, 16)),(p && p!=op))
	   if(!nio_write(addr++, 1, &val, 1))
	     break;
	 break;
       }
     default: fprintf(stderr, "%c?\n", cmd[0]); break;
    }
  }
}


int main(int argc, char *argv[])
{
  int c;
  nio_setup();
#ifdef HAVE_SETUID
  setuid(getuid());
#endif
  while((c=getopt(argc, argv, "hb:"))!=EOF)
    switch(c) {
     case 'h':
       fprintf(stderr, "Usage: %s [-h] [-b bank]\n", argv[0]);
       return 0;
     case 'b':
       if(!nio_set_bank(atoi(optarg)))
	 return 1;
       break;
    }
  do_mon();
  return 0;
}
