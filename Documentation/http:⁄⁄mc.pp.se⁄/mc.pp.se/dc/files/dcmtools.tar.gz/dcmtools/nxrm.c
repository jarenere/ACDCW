#include "config.h"
#include "filesys.h"

#include <stdio.h>
#include <unistd.h>


extern int optind;
extern char *optarg;


int main(int argc, char *argv[])
{
  int c, rc=0;
  struct superblock super;
  struct dir_iterator iter;
  struct dir_entry ent;
  nio_setup();
#ifdef HAVE_SETUID
  setuid(getuid());
#endif
  while((c=getopt(argc, argv, "hb:"))!=EOF)
    switch(c) {
     case 'h':
       fprintf(stderr, "Usage: %s [-h] [-b bank] filename...\n", argv[0]);
       return 0;
     case 'b':
       if(!nio_set_bank(atoi(optarg)))
	 return 1;
       break;
    }
  if(optind>=argc) {
    fprintf(stderr, "%s: Too few arguments.\n", argv[0]);
    return 1;
  }
  if(!fs_get_superblock(&super))
    return 1;
  while(optind<argc) {
    fs_open_dir(&super, &iter);
    if(fs_next_named_dir_entry(&iter, &ent, argv[optind++])) {
      ent.entry[0] = 0;
      if(!fs_write_dir_entry(&ent))
	return 1;
      else {
	unsigned int b;
	for(b=ent.entry[2]|(ent.entry[3]<<8); b!=0xfffa && b!=0xfffc; ) {
	  unsigned int n = fs_get_fat(&super, b);
	  fs_set_fat(&super, b, 0xfffc);
	  b = n;
	}
	if(!fs_sync_superblock(&super))
	  return 1;
      }
    } else {
      fprintf(stderr, "%s: No such file\n", argv[optind-1]);
      rc = 1;
    }
  }
  return rc;
}
