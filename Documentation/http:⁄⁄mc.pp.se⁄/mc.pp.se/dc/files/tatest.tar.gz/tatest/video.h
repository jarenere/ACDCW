extern void init_pvr();
extern void init_video(int cabletype, int mode, int res);
extern int check_cable();
